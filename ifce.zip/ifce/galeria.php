<?php
session_start();
include('admin/conexao.php');
?>


<html lang="pt-BR">

<head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script type="text/javascript" src="js/functions.js"></script>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/stylegaleria.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>NEABI - Núcleo de Estudos Afro-brasileiros e Indígenas</title>
</head>

<body>

    <header>
        <nav>


            <div id="myNav" class="overlay">
                <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
                <div class="overlay-content">
                    <a href="#">Início</a>
                    <a href="#">Galeria</a>
                    <a href="#">Curiosidades</a>
                    <a href="#">Eventos</a>
                </div>
            </div>


            <span style="font-size:40px;cursor:pointer" onclick="openNav()">&#9776;</span>




        </nav>


    </header>

    <main>
        <section>
        <div> 
                <div class="item">
                    <?php
                    $result_news = "SELECT * FROM noticias";
                    $resultado_news = mysqli_query($conexao, $result_news);
                    while ($row_news = mysqli_fetch_array($resultado_news)) {
                        $titulo =  $row_news['titulo'];
                        $noticia = $row_news['noticia'];
                        $img = $row_news['img'];
                        $autor = $row_news['autor'];
                        $data = $row_news['data']; ?>

                        <!-- -->

                </div>
            </div>
            <div  class="row">
            <div class="column">
                    <div class="img">
                        <img src="admin/upload/<?php echo $img; ?>">
                    </div>
                    <?php } ?>
                    </div>
                </div>
            </div>




        </section>
    </main>

    <footer>
        <div>
            <p>Site em desenvolvimento por alunos do IFCE - Campus Paracuru</p>
        </div>
    </footer>

</body>

</html>