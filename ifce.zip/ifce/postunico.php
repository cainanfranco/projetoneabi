<?php
session_start();
include('admin/conexao.php');
?>
<html lang="pt-BR">

<head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="css/style.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>LÓ - Educativo Neabi Campus Paracuru</title>
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" href="https://www.w3schools.com/lib/w3-theme-amber.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script type="text/javascript" src="js/functions.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">


</head>

<body>

    <header>
        <nav class="menu">
            <div id="myNav" class="overlay">
                <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
                <div class="overlay-content">
                    <input type="text" placeholder="Search..">
                    <a href="#">Início</a>
                    <a href="didaticos.php">Materiais Didáticos</a>
                    <a href="#">Questões Socioambientais</a>
                    <a href="#">Ensino e relações étnico raciais</a>
                    <a href="#">Galeria</a>
                    <a href="#">Cultura</a>
                    <a href="#">Eventos</a>
                    <a href="#" onclick="openForm()">Entrar</a>
                </div></a>
                <div class="form-popup" id="myForm">
                    <form action="/action_page.php" class="form-container">
                        <label for="email"><b>Email</b></label>
                        <input type="text" placeholder="Enter Email" name="email" required>
                        <label for="psw"><b>Senha</b></label>
                        <input type="password" placeholder="Senha" name="psw" required>
                        <button type="submit" class="btn">Entrar</button>
                        <button type="button" class="btn cancel" onclick="closeForm()">Fechar</button>
                    </form>
                </div>
            </div>
            <span style="font-size:40px;cursor:pointer" onclick="openNav()">&#9776;</span>
            <div class="icon-bar">
                <a href="#"><i class="fa fa-calendar" aria-hidden="true" alt="Eventos"></i></i></a>
                <a href="didaticos.php"><i class="fa fa-book" aria-hidden="true" alt="Ensino"></i></a>
                <a class="active" href="index.php"><i class="fa fa-home" alt="Inicio"></i></a>
                <a href="#"><i class="fa fa-bullhorn" aria-hidden="true" alt="Avisos"></i></i></a>
                <a href="#"><i class="fa fa-sign-in" aria-hidden="true" alt="Entrar"></i></a>
            </div>
            <div class="logo"><img src="imgs/LOGO.fw.png"></div>
        </nav>
    </header>
    <main>





        <div class="parent white">
            <div class="card purple">
                <h1>Title Here</h1>
                <div class="visual yellow"></div>
                <p>Descriptive Text. Lorem ipsum dolor sit, amet consectetur adipisicing elit. Sed est error repellat veritatis.</p>
            </div>
        </div>


    </main>
    <footer>
        <div>
            <p>Site em desenvolvimento por alunos do IFCE - Campus Paracuru</p>
        </div>
    </footer>
</body>

</html>